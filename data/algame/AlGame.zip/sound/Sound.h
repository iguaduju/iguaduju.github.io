/*
-----------------------------------------------------------------------------
This source file is part of OGRE
(Object-oriented Graphics Rendering Engine)
For the latest info, see http://www.ogre3d.org/

Copyright (c) 2000-2005 The OGRE Team
Also see acknowledgements in Readme.html

You may use this sample code for anything you like, it is not covered by the
LGPL like the rest of the engine.
-----------------------------------------------------------------------------
*/

/*
-----------------------------------------------------------------------------
Filename:    GE2.h
Description: A place for me to try out stuff with OGRE.
-----------------------------------------------------------------------------
*/
#ifndef __SOUND_h_
#define __SOUND_h_

#include <Windows.h>
#include <stdio.h>
#include "dsound.h"
#include "dmusici.h"
#define SOUND_NUM 3

//-------------------------------------------------------------------------------------
class Sound
{
private:
	IDirectMusicLoader8 *g_pLoader;
	IDirectMusicPerformance8 *g_pPerformance;
	IDirectMusicSegment8 *g_pMusic;	
	IDirectMusicSegment8 *g_pBg[SOUND_NUM];	
	int count;
	int timer[SOUND_NUM];
	int timer_end[SOUND_NUM];

public:
	Sound();
	~Sound(void);
	void continueSound(char* type);
	void stopSound();
	void continueMusic(char* type);
	void stopMusic();
};

#endif 