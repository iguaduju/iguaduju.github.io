/*
-----------------------------------------------------------------------------
This source file is part of OGRE
(Object-oriented Graphics Rendering Engine)
For the latest info, see http://www.ogre3d.org/

Copyright (c) 2000-2005 The OGRE Team
Also see acknowledgements in Readme.html

You may use this sample code for anything you like, it is not covered by the
LGPL like the rest of the engine.
-----------------------------------------------------------------------------
*/

#include "Sound.h"

//-------------------------------------------------------------------------------------
// Sound Class
//-------------------------------------------------------------------------------------
Sound::Sound()
{
	// Initialize COM
	CoInitialize(NULL);

	// Create loader object
	CoCreateInstance( CLSID_DirectMusicLoader, NULL, CLSCTX_INPROC, IID_IDirectMusicLoader8, (void**)&g_pLoader );

	// Create performance object
	CoCreateInstance( CLSID_DirectMusicPerformance, NULL, CLSCTX_INPROC, IID_IDirectMusicPerformance8, (void**)&g_pPerformance );

	// Initialize the performance with the standard audio path.
	// This initializes both DirectMusic and DirectSound and 
	// sets up the synthesizer. 
	g_pPerformance->InitAudio( NULL, NULL, NULL, DMUS_APATH_SHARED_STEREOPLUSREVERB, 64, DMUS_AUDIOF_ALL, NULL );

	CHAR strPath[MAX_PATH] = "sound";	/* ���� ��� ���� */
	// Tell DirectMusic where the default search path is
	WCHAR wstrSearchPath[MAX_PATH];
	MultiByteToWideChar( CP_ACP, 0, strPath, -1, wstrSearchPath, MAX_PATH );

	g_pLoader->SetSearchDirectory( GUID_DirectMusicAllTypes, wstrSearchPath, FALSE );

	memset(timer,-1,sizeof(int)*SOUND_NUM);
	memset(g_pBg,NULL,sizeof(IDirectMusicSegment8*)*SOUND_NUM);

	count = 0;
}
Sound::~Sound(void)
{
	// Stop the music, and close down 
	g_pPerformance->Stop( NULL, NULL, 0, 0 );
	g_pPerformance->CloseDown();

	// Cleanup all interfaces
	g_pLoader->Release(); 
	g_pPerformance->Release();
	g_pMusic->Release();

	for(int i=0; i < SOUND_NUM; i++)
		if(g_pBg[i]){
			g_pBg[i]->Release();
		}

	// Close down COM
	CoUninitialize();
}

void Sound::continueMusic(char* type)
{
	if(!strcmp(type,"music1"))
	{
		// Load the segment from the file
		WCHAR wstrFileName[MAX_PATH] = L"bg1.wav";

		stopMusic();
		g_pLoader->LoadObjectFromFile( CLSID_DirectMusicSegment, IID_IDirectMusicSegment8, wstrFileName, (LPVOID*) &g_pMusic );
		// Download the segment's instruments to the synthesizer
		g_pMusic->Download( g_pPerformance );
		//�ݺ�
		g_pMusic->SetRepeats(DMUS_SEG_REPEAT_INFINITE);
		// Play segment on the default audio path
		g_pPerformance->PlaySegmentEx( g_pMusic, NULL, NULL, DMUS_SEGF_SECONDARY, 0, NULL, NULL, NULL );
	}
	else if(!strcmp(type,"music2"))
	{
		// Load the segment from the file
		WCHAR wstrFileName[MAX_PATH] = L"bg2.wav";

		stopMusic();
		g_pLoader->LoadObjectFromFile( CLSID_DirectMusicSegment, IID_IDirectMusicSegment8, wstrFileName, (LPVOID*) &g_pMusic );
		// Download the segment's instruments to the synthesizer
		g_pMusic->Download( g_pPerformance );
		//�ݺ�
		g_pMusic->SetRepeats(DMUS_SEG_REPEAT_INFINITE);
		// Play segment on the default audio path
		g_pPerformance->PlaySegmentEx( g_pMusic, NULL, NULL, DMUS_SEGF_SECONDARY, 0, NULL, NULL, NULL );
	}
	else if(!strcmp(type,"music3"))
	{
		// Load the segment from the file
		WCHAR wstrFileName[MAX_PATH] = L"bg3.wav";

		stopMusic();
		g_pLoader->LoadObjectFromFile( CLSID_DirectMusicSegment, IID_IDirectMusicSegment8, wstrFileName, (LPVOID*) &g_pMusic );
		// Download the segment's instruments to the synthesizer
		g_pMusic->Download( g_pPerformance );
		//�ݺ�
		g_pMusic->SetRepeats(DMUS_SEG_REPEAT_INFINITE);
		// Play segment on the default audio path
		g_pPerformance->PlaySegmentEx( g_pMusic, NULL, NULL, DMUS_SEGF_SECONDARY, 0, NULL, NULL, NULL );
	}

}

void Sound::continueSound(char* type)
{
	WCHAR wstrFileName[MAX_PATH];

	for(int i=0; i <SOUND_NUM; i++){
		if(timer[i] == -1){
			count = i;
			break;
		}
	}

	if(!strcmp(type,"sound1"))
	{
		swprintf(wstrFileName,L"%s",L"button_arrow.wav");
		timer_end[count] = 100;
	}
	else if(!strcmp(type,"sound2"))
	{
		swprintf(wstrFileName,L"%s",L"button_ready.wav");
		timer_end[count] = 100;
	}
	else if(!strcmp(type,"sound3"))
	{
		swprintf(wstrFileName,L"%s",L"button_start.wav");
		timer_end[count] = 550;
	}

	g_pLoader->LoadObjectFromFile( CLSID_DirectMusicSegment, IID_IDirectMusicSegment8, wstrFileName, (LPVOID*) &g_pBg[count] );
	g_pBg[count]->Download( g_pPerformance );
	g_pPerformance->PlaySegmentEx( g_pBg[count], NULL, NULL, DMUS_SEGF_SECONDARY, 0, NULL, NULL, NULL );
	timer[count] = 0;
}

void Sound::stopSound()
{
	for(int i=0; i < SOUND_NUM; i++){
		if(timer[i] != -1)
			timer[i]++;

		if(timer[i] == timer_end[i]){
			g_pPerformance->StopEx(g_pBg[i], 0, 0);	
			timer[i] = -1;
		}
	}
}

void Sound::stopMusic()
{
	g_pPerformance->StopEx(g_pMusic, 0, 0);
}
